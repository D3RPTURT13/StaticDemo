
public class SoccerTeam {
private static int thisWins = 0;
private static int thisLosses = 0;
private static int thisScore = 0;
private static int thisTies = 0;
private static int oppWins = 0;
private static int oppScore = 0;
private static int oppTies = 0;
private static int oppLosses = 0;
private static int thisTRNAMNT = 0;
private static int oppTRNAMNT = 0;
private static int thisGames = 0;
private static int oppGames = 0;
private static int totalGoals = 0;
private static int totalGames = 0;
public void played(SoccerTeam opponent, int myScore, int opponentScore, int myWins, int myLosses, int myTies, int myTournament, int myGames, int opponentWins, int opponentLosses, int opponentTies,  int opponentTournament,  int opponentGames) {
	this.thisScore = myScore;
	this.oppScore = opponentScore;
	this.thisTies = myTies;
	this.oppTies = opponentTies;
	this.thisWins = myWins;
	this.oppWins = opponentWins;
	this.thisLosses = myLosses;
	this.oppLosses = opponentLosses;
	this.thisTRNAMNT = myLosses;
	this.oppTRNAMNT = opponentLosses;
	this.thisGames = myGames;
	this.oppGames = opponentGames;
	this.thisWins++;
	this.oppWins++;
	this.thisTies++;
	this.oppTies++;
	this.thisLosses++;
	this.oppLosses++;
	this.thisGames++;
	this.oppGames++;
	this.totalGames++;
	if (myScore == opponentScore) {
thisTRNAMNT = thisTRNAMNT+1;
oppTRNAMNT = oppTRNAMNT+1;
thisTies = thisTies + 1;
oppTies = oppTies + 1;
thisGames = thisGames+1;
oppGames = oppGames+1;
totalGames = totalGames+2;
totalGoals = totalGoals + myScore + opponentScore;
	}
	if (myScore < opponentScore) {
		thisTRNAMNT = thisTRNAMNT+3;
		oppWins = oppWins + 1;
		thisLosses = thisLosses + 1;
		thisGames = thisGames+1;
		oppGames = oppGames+1;
		totalGames = totalGames+2;
		totalGoals = totalGoals + myScore + opponentScore;
	}
	if (myScore > opponentScore) {
		thisTRNAMNT = thisTRNAMNT+3;
		thisWins = thisWins + 1;
		oppLosses = oppLosses + 1;
		thisGames = thisGames+1;
		oppGames = oppGames+1;
		totalGames = totalGames+2;
		totalGoals = totalGoals + myScore + opponentScore;
	}
	
	}
public static void Reset() {
	thisWins = 0;
	thisLosses = 0;
	thisTies = 0;
}
 }

