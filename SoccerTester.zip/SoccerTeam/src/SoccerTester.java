
public class SoccerTester extends SoccerTeam {
	public static void main(String[] args) {
		super(int myScore, int opponentScore, int myWins, int myLosses, int myTies, int myTournament, int myGames, int opponentWins, int opponentLosses, int opponentTies,  int opponentTournament,  int opponentGames)
thisWins = 5;
thisLosses = 6;
thisScore = 10;
thisTies = 7;
opponentWins = 6;
oppScore = 10;
oppTies = 7;
oppLosses = 5;
thisTRNAMNT = 22;
oppTRNAMNT = 23;
thisGames = 18;
oppGames = 18;
totalGoals = 173;
totalGames = 36;
System.out.println("My Team Wins: " + thisWins);
System.out.println("My Team Losses: " + thisLosses);
System.out.println("My Team Ties: " + thisTies);
System.out.println("My Team Tournament Score: " + thisTRNAMNT);
System.out.println("Opponent Team Wins: " + oppWins);
System.out.println("Opponent Team Losses: " + oppLosses);
System.out.println("Opponent Team Ties: " + oppTies);
System.out.println("Opponent Team Tournament Score: " + oppTRNAMNT);
System.out.println("My Team Total Games: " + thisGames);
System.out.println("Opponent Team Games: " + oppGames);
System.out.println("Total Goals(all): " + totalGoals);
System.out.println("My Total Games(all): " + totalGames);
}
}
